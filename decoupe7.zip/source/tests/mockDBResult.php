<?php

class MockDBResult{
    function fetch_object(){
        return array('test' => 'test');
    }
}